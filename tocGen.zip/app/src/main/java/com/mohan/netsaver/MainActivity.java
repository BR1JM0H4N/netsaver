package com.mohan.netsaver;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.color.DynamicColors;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.SequenceInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.LinkedHashMap;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity extends AppCompatActivity {

    // ─── Views ────────────────────────────────────────────────
    private WebView                  webView;
    private EditText                 urlInput;
    private ImageButton              btnBack, btnForward, btnRefresh, btnMenu;
    private ImageButton              btnHome, btnSavedFiles, btnShare, btnNewTab;
    private ImageButton              btnClearUrl;
    private ImageView                iconSecurity;
    private LinearProgressIndicator  pageLoadProgress;
    private LinearLayout             saveIndicator;
    private TextView                 saveIndicatorText;
    private View                     statusBarSpacer, navBarSpacer;

    // ─── Networking ───────────────────────────────────────────
    private final OkHttpClient client = new OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .build();

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private static final String HOME_URL = "https://duckduckgo.com/";

    // Track URLs already being saved (avoid duplicate saves of same segment)
    private final java.util.Set<String> savingUrls =
            java.util.Collections.synchronizedSet(new java.util.HashSet<>());

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DynamicColors.applyToActivityIfAvailable(this);
        setContentView(R.layout.activity_main);

        initViews();
        applyWindowInsets();
        setupWebView();
        setupListeners();

        webView.loadUrl(HOME_URL);
    }

    // ─── Init ─────────────────────────────────────────────────

    private void initViews() {
        webView           = findViewById(R.id.webView);
        urlInput          = findViewById(R.id.urlInput);
        btnBack           = findViewById(R.id.btnBack);
        btnForward        = findViewById(R.id.btnForward);
        btnRefresh        = findViewById(R.id.btnRefresh);
        btnMenu           = findViewById(R.id.btnMenu);
        btnHome           = findViewById(R.id.btnHome);
        btnSavedFiles     = findViewById(R.id.btnSavedFiles);
        btnShare          = findViewById(R.id.btnShare);
        btnNewTab         = findViewById(R.id.btnNewTab);
        btnClearUrl       = findViewById(R.id.btnClearUrl);
        iconSecurity      = findViewById(R.id.iconSecurity);
        pageLoadProgress  = findViewById(R.id.pageLoadProgress);
        saveIndicator     = findViewById(R.id.saveIndicator);
        saveIndicatorText = findViewById(R.id.saveIndicatorText);
        statusBarSpacer   = findViewById(R.id.statusBarSpacer);
        navBarSpacer      = findViewById(R.id.navBarSpacer);
    }

    /** Push toolbar below status bar and bottom bar above nav bar */
    private void applyWindowInsets() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            findViewById(R.id.rootLayout).setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getInsets(WindowInsets.Type.statusBars()).top;
                int bot = insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                statusBarSpacer.getLayoutParams().height = top;
                statusBarSpacer.requestLayout();
                navBarSpacer.getLayoutParams().height = bot;
                navBarSpacer.requestLayout();
                return insets;
            });
        }
    }

    // ─── WebView setup ────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        // Modern mobile UA
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"
        );

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                if (p < 100) {
                    pageLoadProgress.setVisibility(View.VISIBLE);
                    pageLoadProgress.setProgressCompat(p, true);
                } else {
                    pageLoadProgress.setVisibility(View.GONE);
                }
                // Update refresh/stop icon
                btnRefresh.setImageResource(p < 100
                        ? R.drawable.ic_stop : R.drawable.ic_refresh);
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                // keep URL bar showing URL, not title
            }
        });

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap fav) {
                mainHandler.post(() -> {
                    urlInput.setText(url);
                    updateUrlBarSecurity(url);
                    updateNavButtons();
                });
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                mainHandler.post(() -> {
                    urlInput.setText(url);
                    updateUrlBarSecurity(url);
                    updateNavButtons();
                    pageLoadProgress.setVisibility(View.GONE);
                    btnRefresh.setImageResource(R.drawable.ic_refresh);
                });
            }

            /**
             * ═══════════════════════════════════════════════════════════════
             *  INTERCEPT + TEE STREAM — called on a background (IO) thread
             * ═══════════════════════════════════════════════════════════════
             *
             * Detection strategy (fixes why v2 never saved anything):
             *
             *  1. URL pattern  — covers well-known extensions/paths
             *  2. Content-Type — confirms matched URLs are media/images before teeing.
             *
             * What we do NOT save:
             *  • .m3u8 playlists  — text manifests, useless as standalone files
             */
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {

                String url   = request.getUrl().toString();
                String lower = url.toLowerCase(Locale.ROOT);

                // Only intercept requests that are likely media. When intercepted,
                // the OkHttp response is returned to WebView, so this replaces the
                // WebView fetch instead of adding a second network download.
                if (shouldTrySavingRequest(request, lower)) {
                    return teeStream(url, request);
                }

                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String url = req.getUrl().toString();
                if (url.startsWith("tel:") || url.startsWith("mailto:") ||
                        url.startsWith("sms:") || url.startsWith("intent:")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (ActivityNotFoundException ignored) {}
                    return true;
                }
                return false;
            }
        });
    }

    // ─── Saveable file detection ─────────────────────────────

    /**
     * Returns true when the request is worth intercepting as possible media.
     *
     * Intercepting does not double-download matching requests: teeStream returns
     * its OkHttp response body back to WebView. We still keep this filter fairly
     * strict to avoid replacing normal page, script, and stylesheet loads.
     */
    private boolean shouldTrySavingRequest(WebResourceRequest request, String lower) {
        if (!"GET".equalsIgnoreCase(request.getMethod())) return false;

        String scheme = request.getUrl().getScheme();
        if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return false;

        if (looksLikeSavableFileByUrl(lower)) return true;

        // Gallery sites commonly hide full-size images behind extensionless CDN
        // URLs (for example /media/abc123?w=1200&format=webp).  To catch those
        // without spending extra bandwidth, we replace the browser request with
        // our OkHttp request and only save after the response Content-Type/magic
        // bytes prove it is media. Non-media probe responses are passed straight
        // back to WebView instead of making WebView fetch them again.
        if (request.isForMainFrame()) return false;

        String fetchDest = getRequestHeader(request, "Sec-Fetch-Dest");
        if (fetchDest != null) {
            String dest = fetchDest.toLowerCase(Locale.ROOT);
            if (dest.equals("image") || dest.equals("video") || dest.equals("audio")) return true;
            if (dest.equals("script") || dest.equals("style") || dest.equals("font") ||
                    dest.equals("document") || dest.equals("iframe")) return false;
        }

        String accept = getRequestHeader(request, "Accept");
        if (accept != null) {
            String lowerAccept = accept.toLowerCase(Locale.ROOT);
            if (lowerAccept.contains("image/") || lowerAccept.contains("video/") ||
                    lowerAccept.contains("audio/")) return true;
            if (lowerAccept.contains("text/html") || lowerAccept.contains("text/css") ||
                    lowerAccept.contains("javascript") || lowerAccept.contains("application/json")) {
                return false;
            }
        }

        if (looksLikeNonSavableAssetByUrl(lower)) return false;

        return hasGalleryMediaPathHint(lower) || hasImageTransformationHint(lower);
    }

    private static String getRequestHeader(WebResourceRequest request, String wantedName) {
        for (Map.Entry<String, String> e : request.getRequestHeaders().entrySet()) {
            if (e.getKey().equalsIgnoreCase(wantedName)) return e.getValue();
        }
        return null;
    }

    /**
     * Returns true if the URL strongly suggests a saveable media or image file.
     *
     * Deliberately excludes .m3u8 (playlist text, not playable standalone)
     * and generic "video" words without a concrete extension (too noisy).
     */
    private boolean looksLikeSavableFileByUrl(String lower) {
        // Concrete image extensions
        if (segmentPattern(lower, ".jpg")  || segmentPattern(lower, ".jpeg") ||
            segmentPattern(lower, ".png")  || segmentPattern(lower, ".webp") ||
            segmentPattern(lower, ".gif")  || segmentPattern(lower, ".bmp")  ||
            segmentPattern(lower, ".heic") || segmentPattern(lower, ".heif") ||
            segmentPattern(lower, ".avif") || segmentPattern(lower, ".svg")) return true;

        // Concrete video extensions
        if (segmentPattern(lower, ".mp4")  || segmentPattern(lower, ".webm") ||
            segmentPattern(lower, ".mkv")  || segmentPattern(lower, ".avi")  ||
            segmentPattern(lower, ".mov"))  return true;

        // Audio
        if (segmentPattern(lower, ".mp3")  || segmentPattern(lower, ".aac")  ||
            segmentPattern(lower, ".ogg")  || segmentPattern(lower, ".opus") ||
            segmentPattern(lower, ".flac") || segmentPattern(lower, ".m4a"))  return true;

        // HLS transport stream segments (NOT the .m3u8 playlist itself)
        // Matches both ".ts" and ".ts?token=xxx"
        if (segmentPattern(lower, ".ts")) return true;

        // DASH segments – common patterns from major CDNs
        if (lower.contains("dash") && (lower.contains("video") || lower.contains("audio"))) return true;
        if (lower.contains("/seg-") && (lower.contains("-v") || lower.contains("-a"))) return true;
        if (lower.contains("segment") && (lower.contains("video") || lower.contains("audio"))) return true;
        if (lower.contains("/chunk_") || lower.contains("/chunk-")) return true;

        // YouTube-style itag URLs (they never have an extension)
        if (lower.contains("googlevideo.com") && lower.contains("itag=")) return true;

        // Common CDN segment paths
        if ((lower.contains("/hls/") || lower.contains("/hlsvod/")) &&
            !lower.endsWith(".m3u8") && !lower.endsWith(".m3u8?") &&
            !lower.contains("playlist")) return true;

        return false;
    }

    /**
     * True if url contains ext as a file extension. Many gallery/CDN URLs put
     * resize path segments after the original name (photo.jpg/1200x800) or use
     * suffixes (photo.jpg:large), so accept any non-letter/digit after the ext.
     */
    private static boolean segmentPattern(String lower, String ext) {
        int idx = lower.indexOf(ext);
        while (idx >= 0) {
            int before = idx - 1;
            int after = idx + ext.length();
            boolean startsLikeExtension = before >= 0 && Character.isLetterOrDigit(lower.charAt(before));
            boolean endsLikeExtension = after == lower.length() || !Character.isLetterOrDigit(lower.charAt(after));
            if (startsLikeExtension && endsLikeExtension) return true;
            idx = lower.indexOf(ext, after);
        }
        return false;
    }

    private static boolean hasGalleryMediaPathHint(String lower) {
        return lower.contains("/image")
            || lower.contains("/img")
            || lower.contains("/photo")
            || lower.contains("/picture")
            || lower.contains("/pic/")
            || lower.contains("/thumb")
            || lower.contains("/thumbnail")
            || lower.contains("/preview")
            || lower.contains("/sample")
            || lower.contains("/media/")
            || lower.contains("/uploads/")
            || lower.contains("/cdn-cgi/image/")
            || lower.contains("/resize/")
            || lower.contains("/assets/");
    }

    private static boolean hasImageTransformationHint(String lower) {
        return lower.contains("format=webp")
            || lower.contains("format=jpg")
            || lower.contains("format=jpeg")
            || lower.contains("format=png")
            || lower.contains("fm=webp")
            || lower.contains("fm=jpg")
            || lower.contains("fm=jpeg")
            || lower.contains("fm=png")
            || lower.contains("width=")
            || lower.contains("height=")
            || lower.contains("&w=")
            || lower.contains("?w=")
            || lower.contains("&h=")
            || lower.contains("?h=")
            || lower.contains("quality=")
            || lower.contains("&q=")
            || lower.contains("?q=")
            || lower.contains("fit=")
            || lower.contains("crop=")
            || lower.contains("resize=");
    }

    private static boolean looksLikeNonSavableAssetByUrl(String lower) {
        return segmentPattern(lower, ".js")
            || segmentPattern(lower, ".css")
            || segmentPattern(lower, ".json")
            || segmentPattern(lower, ".html")
            || segmentPattern(lower, ".htm")
            || segmentPattern(lower, ".xml")
            || segmentPattern(lower, ".woff")
            || segmentPattern(lower, ".woff2")
            || segmentPattern(lower, ".ttf")
            || segmentPattern(lower, ".otf")
            || segmentPattern(lower, ".ico");
    }

    /**
     * Returns a savable MIME type when either the server Content-Type or the URL
     * itself identifies media. A URL extension is intentionally allowed to win
     * over generic or wrong server types because many cache-busted media links are
     * served as application/octet-stream or text/plain even though they are files.
     */
    private String getSavableMimeType(String url, String rawContentType) {
        String serverMime = rawContentType == null ? "" : rawContentType.split(";")[0].trim();
        if (isSavableContentType(serverMime)) return serverMime;

        String guessedMime = guessMime(url);
        if (isSavableContentType(guessedMime) &&
                looksLikeSavableFileByUrl(url.toLowerCase(Locale.ROOT))) {
            return guessedMime;
        }

        return null;
    }

    private static String sniffMimeType(byte[] bytes, int length) {
        if (bytes == null || length <= 0) return null;

        if (length >= 3 &&
                (bytes[0] & 0xFF) == 0xFF &&
                (bytes[1] & 0xFF) == 0xD8 &&
                (bytes[2] & 0xFF) == 0xFF) return "image/jpeg";
        if (startsWith(bytes, length, new byte[] {(byte) 0x89, 'P', 'N', 'G'})) return "image/png";
        if (startsWith(bytes, length, "GIF87a") || startsWith(bytes, length, "GIF89a")) return "image/gif";
        if (startsWith(bytes, length, "BM")) return "image/bmp";
        if (length >= 12 && startsWith(bytes, length, "RIFF") && asciiEquals(bytes, 8, "WEBP")) return "image/webp";
        if (containsAscii(bytes, length, "ftypavif") || containsAscii(bytes, length, "ftypavis")) return "image/avif";
        if (containsAscii(bytes, length, "ftypheic") || containsAscii(bytes, length, "ftypheix") ||
                containsAscii(bytes, length, "ftyphevc") || containsAscii(bytes, length, "ftypmif1")) return "image/heic";
        if (startsWith(bytes, length, "OggS")) return "audio/ogg";
        if (startsWith(bytes, length, "ID3") ||
                (length >= 2 && (bytes[0] & 0xFF) == 0xFF && ((bytes[1] & 0xE0) == 0xE0))) return "audio/mpeg";
        if (containsAscii(bytes, length, "ftypmp4") || containsAscii(bytes, length, "ftypisom") ||
                containsAscii(bytes, length, "ftypM4V") || containsAscii(bytes, length, "ftypMSNV")) return "video/mp4";

        String start = new String(bytes, 0, Math.min(length, 128)).trim().toLowerCase(Locale.ROOT);
        if (start.startsWith("<svg") || start.contains("<svg")) return "image/svg+xml";

        return null;
    }

    private static boolean startsWith(byte[] bytes, int length, String prefix) {
        return asciiEquals(bytes, length, 0, prefix);
    }

    private static boolean startsWith(byte[] bytes, int length, byte[] prefix) {
        if (length < prefix.length) return false;
        for (int i = 0; i < prefix.length; i++) {
            if (bytes[i] != prefix[i]) return false;
        }
        return true;
    }

    private static boolean containsAscii(byte[] bytes, int length, String needle) {
        for (int i = 0; i <= length - needle.length(); i++) {
            if (asciiEquals(bytes, length, i, needle)) return true;
        }
        return false;
    }

    private static boolean asciiEquals(byte[] bytes, int offset, String value) {
        return asciiEquals(bytes, bytes.length, offset, value);
    }

    private static boolean asciiEquals(byte[] bytes, int length, int offset, String value) {
        if (offset < 0 || length < offset + value.length()) return false;
        for (int i = 0; i < value.length(); i++) {
            if ((byte) value.charAt(i) != bytes[offset + i]) return false;
        }
        return true;
    }

    /**
     * Check the Content-Type of a response to confirm it's media or an image.
     * Used as a secondary check when the URL pattern isn't conclusive.
     */
    private static boolean isSavableContentType(String ct) {
        if (ct == null || ct.isEmpty()) return false;
        String lower = ct.toLowerCase(Locale.ROOT);
        return lower.startsWith("video/")
            || lower.startsWith("audio/")
            || lower.startsWith("image/")
            || lower.contains("mp4")
            || lower.contains("webm")
            || lower.contains("mp2t")
            || lower.contains("mpeg");
    }

    // ─── Tee streaming ────────────────────────────────────────

    /**
     * Makes ONE OkHttp request for the URL.
     * Returns a WebResourceResponse whose InputStream is a TeeInputStream:
     *   network bytes → WebView  (playback)
     *               └→ file     (saved to disk)
     *
     * Zero extra bandwidth. No second request.
     */
    private WebResourceResponse teeStream(String url, WebResourceRequest original) {

        // Deduplicate: don't save the same URL twice in parallel
        if (!savingUrls.add(url)) {
            // Already in progress — let WebView fetch it normally
            return null;
        }

        try {
            Request.Builder rb = new Request.Builder().url(url);

            // Forward original request headers so CDNs don't reject us. If WebView
            // omits Cookie from this callback, copy the page cookies explicitly so
            // authenticated/gallery images can still be fetched by the replacement
            // OkHttp request.
            boolean hasCookieHeader = false;
            for (Map.Entry<String, String> e : original.getRequestHeaders().entrySet()) {
                String key = e.getKey();
                if (key.equalsIgnoreCase("cookie")) hasCookieHeader = true;
                if (!key.equalsIgnoreCase("host") &&
                    !key.equalsIgnoreCase("content-length") &&
                    !key.equalsIgnoreCase("connection")) {
                    try { rb.header(key, e.getValue()); }
                    catch (IllegalArgumentException ignored) {} // skip malformed headers
                }
            }
            if (!hasCookieHeader) {
                String cookie = CookieManager.getInstance().getCookie(url);
                if (!TextUtils.isEmpty(cookie)) rb.header("Cookie", cookie);
            }

            Response response = client.newCall(rb.build()).execute();

            ResponseBody body = response.body();
            if (body == null) {
                response.close();
                savingUrls.remove(url);
                return null;
            }

            // Determine MIME. Some CDNs serve image/video files with generic or
            // incorrect Content-Type values (for example application/octet-stream),
            // so a strong URL extension match should still be saved with the MIME
            // guessed from the URL. This fixes image URLs such as .jpg?cacheBust.
            InputStream responseStream = body.byteStream();
            byte[] sniffBuffer = new byte[512];
            int sniffedBytes = responseStream.read(sniffBuffer);
            InputStream fullResponseStream = sniffedBytes > 0
                    ? new SequenceInputStream(
                            new ByteArrayInputStream(sniffBuffer, 0, sniffedBytes),
                            responseStream)
                    : responseStream;

            String rawCt = response.header("content-type", "");
            String mimeType = getSavableMimeType(url, rawCt);
            if (mimeType == null) mimeType = sniffMimeType(sniffBuffer, sniffedBytes);

            // Secondary filter: confirm it's actually media/image by Content-Type,
            // by a concrete media extension in the URL, or by magic bytes.
            if (!response.isSuccessful() || mimeType == null) {
                // Not saveable, but we already made the network request. Return
                // the same response body to WebView instead of returning null,
                // which would make WebView re-request it and use more data.
                savingUrls.remove(url);
                String passThroughMime = !TextUtils.isEmpty(rawCt)
                        ? rawCt.split(";")[0].trim()
                        : "application/octet-stream";
                return buildWebResourceResponse(response, passThroughMime, fullResponseStream);
            }

            // Build save path. If saving cannot start, still pass the already
            // fetched response to WebView so we do not force a second request.
            String fileName = buildFileName(url, mimeType);
            FileOutputStream fileOut;
            try {
                File saveFile = getSaveFile(fileName, mimeType);
                fileOut = new FileOutputStream(saveFile);
            } catch (Exception saveError) {
                saveError.printStackTrace();
                savingUrls.remove(url);
                return buildWebResourceResponse(response, mimeType, fullResponseStream);
            }

            // The tee: one stream, two sinks
            TeeInputStream tee = new TeeInputStream(fullResponseStream, fileOut) {
                @Override
                public void close() throws java.io.IOException {
                    try { super.close(); }
                    finally {
                        savingUrls.remove(url);
                        mainHandler.post(() -> hideSaveIndicator());
                    }
                }
            };

            // Notify UI
            mainHandler.post(() -> showSaveIndicator(fileName));

            return buildWebResourceResponse(response, mimeType, tee);

        } catch (Exception e) {
            e.printStackTrace();
            savingUrls.remove(url);
            return null;
        }
    }

    private WebResourceResponse buildWebResourceResponse(
            Response response, String mimeType, InputStream stream) {
        // Build response headers (strip encoding/length that would confuse WebView)
        Map<String, String> headers = new LinkedHashMap<>();
        for (String name : response.headers().names()) {
            String lname = name.toLowerCase(Locale.ROOT);
            if (!lname.equals("content-encoding") &&
                !lname.equals("transfer-encoding") &&
                !lname.equals("content-length")) {
                headers.put(name, response.header(name, ""));
            }
        }
        headers.put("Content-Type", mimeType);
        headers.put("Access-Control-Allow-Origin", "*");
        headers.put("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");

        return new WebResourceResponse(
                mimeType,
                getResponseEncoding(mimeType),
                response.code(),
                TextUtils.isEmpty(response.message()) ? "OK" : response.message(),
                headers,
                stream
        );
    }

    private static String getResponseEncoding(String mimeType) {
        if (mimeType == null) return "binary";
        String lower = mimeType.toLowerCase(Locale.ROOT);
        return lower.startsWith("text/") ||
                lower.contains("json") ||
                lower.contains("xml") ||
                lower.contains("javascript")
                ? "UTF-8"
                : "binary";
    }

    // ─── File helpers ─────────────────────────────────────────

    private String guessMime(String url) {
        String lower = url.toLowerCase(Locale.ROOT);
        if (lower.contains(".jpg") || lower.contains(".jpeg")) return "image/jpeg";
        if (lower.contains(".png"))  return "image/png";
        if (lower.contains(".webp")) return "image/webp";
        if (lower.contains(".gif"))  return "image/gif";
        if (lower.contains(".bmp"))  return "image/bmp";
        if (lower.contains(".heic")) return "image/heic";
        if (lower.contains(".heif")) return "image/heif";
        if (lower.contains(".avif")) return "image/avif";
        if (lower.contains(".svg"))  return "image/svg+xml";
        if (lower.contains(".mp4"))  return "video/mp4";
        if (lower.contains(".webm")) return "video/webm";
        if (lower.contains(".ts"))   return "video/mp2t";
        if (lower.contains(".mp3"))  return "audio/mpeg";
        if (lower.contains(".aac"))  return "audio/aac";
        if (lower.contains(".ogg"))  return "audio/ogg";
        if (lower.contains(".m4a"))  return "audio/mp4";
        return "application/octet-stream";
    }

    private String buildFileName(String url, String mime) {
        // Strip query/fragment
        String path = url;
        int q = path.indexOf('?'); if (q > 0) path = path.substring(0, q);
        int h = path.indexOf('#'); if (h > 0) path = path.substring(0, h);

        String name = path.substring(path.lastIndexOf('/') + 1);

        String ext = extensionForMime(mime);

        // If name is empty or looks like a huge random token, generate one.
        // Otherwise, preserve extensionless CDN names but append an extension so
        // Android/gallery MIME detection can recognize the saved file later.
        if (name.isEmpty() || (!name.contains(".") && name.length() > 40) || name.length() > 120) {
            name = "netsaver_" + System.currentTimeMillis() + ext;
        } else if (!name.contains(".")) {
            name = name + ext;
        }
        return name;
    }

    private static String extensionForMime(String mime) {
        String lower = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        return lower.contains("jpeg")  ? ".jpg"
             : lower.contains("png")   ? ".png"
             : lower.contains("webp")  ? ".webp"
             : lower.contains("gif")   ? ".gif"
             : lower.contains("bmp")   ? ".bmp"
             : lower.contains("heic")  ? ".heic"
             : lower.contains("heif")  ? ".heif"
             : lower.contains("avif")  ? ".avif"
             : lower.contains("svg")   ? ".svg"
             : lower.contains("mp4")   ? ".mp4"
             : lower.contains("webm")  ? ".webm"
             : lower.contains("mp2t")  ? ".ts"
             : lower.contains("mpeg")  ? ".mp3"
             : lower.contains("aac")   ? ".aac"
             : lower.contains("ogg")   ? ".ogg"
             : ".media";
    }

    private File getSaveFile(String fileName, String mimeType) {
        String directoryType = mimeType != null && mimeType.toLowerCase(Locale.ROOT).startsWith("image/")
                ? Environment.DIRECTORY_PICTURES
                : Environment.DIRECTORY_MOVIES;
        File dir = new File(getExternalFilesDir(directoryType), "NetSaver");
        if (!dir.exists()) dir.mkdirs();
        File f = new File(dir, fileName);
        if (f.exists()) {
            String base = fileName.contains(".")
                    ? fileName.substring(0, fileName.lastIndexOf('.')) : fileName;
            String ext  = fileName.contains(".")
                    ? fileName.substring(fileName.lastIndexOf('.'))    : "";
            f = new File(dir, base + "_" + System.currentTimeMillis() + ext);
        }
        return f;
    }

    // ─── UI helpers ───────────────────────────────────────────

    private void showSaveIndicator(String fileName) {
        saveIndicatorText.setText("Saving: " + fileName);
        saveIndicator.setVisibility(View.VISIBLE);
    }

    private void hideSaveIndicator() {
        saveIndicator.setVisibility(View.GONE);
    }

    private void updateNavButtons() {
        btnBack.setAlpha(webView.canGoBack()    ? 1.0f : 0.38f);
        btnForward.setAlpha(webView.canGoForward() ? 1.0f : 0.38f);
    }

    private void updateUrlBarSecurity(String url) {
        if (url != null && url.startsWith("https://")) {
            iconSecurity.setImageResource(R.drawable.ic_lock);
        } else {
            iconSecurity.setImageResource(R.drawable.ic_lock_open);
        }
    }

    // ─── Listeners ────────────────────────────────────────────

    private void setupListeners() {

        btnBack.setOnClickListener(v -> { if (webView.canGoBack()) webView.goBack(); });
        btnForward.setOnClickListener(v -> { if (webView.canGoForward()) webView.goForward(); });

        btnRefresh.setOnClickListener(v -> {
            if (pageLoadProgress.getVisibility() == View.VISIBLE) webView.stopLoading();
            else webView.reload();
        });

        // URL bar keyboard action
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                navigate(urlInput.getText().toString().trim());
                hideKeyboard();
                return true;
            }
            return false;
        });

        urlInput.setOnFocusChangeListener((v, focused) -> {
            btnClearUrl.setVisibility(focused ? View.VISIBLE : View.GONE);
            if (focused) urlInput.selectAll();
        });

        btnClearUrl.setOnClickListener(v -> {
            urlInput.setText("");
            urlInput.requestFocus();
        });

        // Bottom bar
        btnHome.setOnClickListener(v -> webView.loadUrl(HOME_URL));

        btnSavedFiles.setOnClickListener(v -> showSavedFilesDialog());

        btnShare.setOnClickListener(v -> {
            String url = webView.getUrl();
            if (url != null) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, url);
                startActivity(Intent.createChooser(share, "Share"));
            }
        });

        btnNewTab.setOnClickListener(v -> {
            String url = webView.getUrl();
            if (url != null) {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (ActivityNotFoundException ignored) {}
            }
        });

        // Overflow menu
        btnMenu.setOnClickListener(v -> {
            PopupMenu pm = new PopupMenu(this, v);
            pm.getMenu().add(0, 1, 0, "Reload page");
            pm.getMenu().add(0, 2, 1, "Toggle desktop site");
            pm.getMenu().add(0, 3, 2, "Saved files");
            pm.getMenu().add(0, 4, 3, "Share page");
            pm.getMenu().add(0, 5, 4, "Open in browser");
            pm.getMenu().add(0, 6, 5, "Clear cache");
            pm.setOnMenuItemClickListener(item -> {
                switch (item.getItemId()) {
                    case 1: webView.reload(); return true;
                    case 2: toggleDesktopSite(); return true;
                    case 3: showSavedFilesDialog(); return true;
                    case 4: btnShare.performClick(); return true;
                    case 5: btnNewTab.performClick(); return true;
                    case 6: clearCache(); return true;
                }
                return false;
            });
            pm.show();
        });
    }

    private void navigate(String input) {
        if (TextUtils.isEmpty(input)) return;
        String url;
        if (input.startsWith("http://") || input.startsWith("https://")) {
            url = input;
        } else if (input.contains(".") && !input.contains(" ") && !input.startsWith(".")) {
            url = "https://" + input;
        } else {
            url = "https://duckduckgo.com/?q=" + Uri.encode(input);
        }
        webView.loadUrl(url);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void toggleDesktopSite() {
        WebSettings s = webView.getSettings();
        boolean isDesktop = s.getUserAgentString().contains("Windows");
        if (isDesktop) {
            s.setUserAgentString(
                "Mozilla/5.0 (Linux; Android 14; Pixel 8) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Mobile Safari/537.36");
        } else {
            s.setUserAgentString(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36");
        }
        webView.reload();
    }

    private void clearCache() {
        webView.clearCache(true);
        webView.clearHistory();
        android.widget.Toast.makeText(this, "Cache cleared", android.widget.Toast.LENGTH_SHORT).show();
    }

    private void showSavedFilesDialog() {
        List<SavedFile> files = getSavedFiles();
        if (files.isEmpty()) {
            android.widget.Toast.makeText(this, "No saved files yet", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }

        View content = LayoutInflater.from(this).inflate(R.layout.dialog_saved_gallery, null, false);
        TextView subtitle = content.findViewById(R.id.gallerySubtitle);
        RecyclerView grid = content.findViewById(R.id.savedGalleryGrid);

        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        Runnable updateSubtitle = () -> subtitle.setText(files.size() + " saved item" + (files.size() == 1 ? "" : "s")
                + " · tap a card to view");

        SavedGalleryAdapter adapter = new SavedGalleryAdapter(files, () -> {
            if (files.isEmpty()) {
                dialog.dismiss();
                android.widget.Toast.makeText(this, "No saved files left", android.widget.Toast.LENGTH_SHORT).show();
            } else {
                updateSubtitle.run();
            }
        });

        grid.setLayoutManager(new GridLayoutManager(this, 2));
        grid.setAdapter(adapter);
        updateSubtitle.run();

        content.findViewById(R.id.btnGalleryClose).setOnClickListener(v -> dialog.dismiss());
        content.findViewById(R.id.btnGalleryDone).setOnClickListener(v -> dialog.dismiss());
        content.findViewById(R.id.btnGalleryDeleteAll).setOnClickListener(v -> {
            for (SavedFile sf : new ArrayList<>(files)) sf.file.delete();
            files.clear();
            adapter.notifyDataSetChanged();
            dialog.dismiss();
            android.widget.Toast.makeText(this, "Deleted all saved files", android.widget.Toast.LENGTH_SHORT).show();
        });

        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
        });
        dialog.show();
    }

    private List<SavedFile> getSavedFiles() {
        List<SavedFile> files = new ArrayList<>();
        collectSavedFiles(files, Environment.DIRECTORY_MOVIES);
        collectSavedFiles(files, Environment.DIRECTORY_PICTURES);
        files.sort((a, b) -> Long.compare(b.file.lastModified(), a.file.lastModified()));
        return files;
    }

    private void collectSavedFiles(List<SavedFile> files, String directoryType) {
        File dir = new File(getExternalFilesDir(directoryType), "NetSaver");
        if (dir.exists() && dir.listFiles() != null) {
            for (File f : dir.listFiles()) {
                if (f.isFile()) files.add(new SavedFile(f));
            }
        }
    }

    private void openFile(File file) {
        Uri uri = getContentUri(file);
        String mt = guessMime(file.getName());
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, mt);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(i); }
        catch (ActivityNotFoundException e) {
            android.widget.Toast.makeText(this, "No app to open this file", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private void shareSavedFile(File file) {
        Uri uri = getContentUri(file);
        String mt = guessMime(file.getName());
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(mt);
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.putExtra(Intent.EXTRA_SUBJECT, file.getName());
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(share, "Share saved content")); }
        catch (ActivityNotFoundException e) {
            android.widget.Toast.makeText(this, "No app to share this file", android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    private Uri getContentUri(File file) {
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
    }

    private boolean isImageFile(File file) {
        String mt = guessMime(file.getName());
        return mt.startsWith("image/") && !mt.equals("image/svg+xml");
    }

    private String getGalleryKind(File file) {
        String mt = guessMime(file.getName());
        if (mt.startsWith("image/")) return "Image";
        if (mt.startsWith("audio/")) return "Audio";
        if (mt.startsWith("video/")) return "Video";
        return "File";
    }

    private class SavedGalleryAdapter extends RecyclerView.Adapter<SavedGalleryAdapter.ViewHolder> {
        private final List<SavedFile> files;
        private final Runnable onChanged;

        SavedGalleryAdapter(List<SavedFile> files, Runnable onChanged) {
            this.files = files;
            this.onChanged = onChanged;
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_saved_gallery, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            SavedFile saved = files.get(position);
            holder.name.setText(saved.displayName);
            holder.meta.setText(saved.getFormattedSize());
            holder.kind.setText(getGalleryKind(saved.file));

            if (isImageFile(saved.file)) {
                holder.preview.setPadding(0, 0, 0, 0);
                holder.preview.setImageURI(Uri.fromFile(saved.file));
            } else {
                int pad = (int) (28 * getResources().getDisplayMetrics().density);
                holder.preview.setPadding(pad, pad, pad, pad);
                holder.preview.setImageResource(R.drawable.ic_video);
            }

            holder.itemView.setOnClickListener(v -> openFile(saved.file));
            holder.share.setOnClickListener(v -> shareSavedFile(saved.file));
            holder.delete.setOnClickListener(v -> {
                int current = holder.getBindingAdapterPosition();
                if (current == RecyclerView.NO_POSITION) return;
                SavedFile removed = files.remove(current);
                removed.file.delete();
                notifyItemRemoved(current);
                onChanged.run();
            });
        }

        @Override
        public int getItemCount() {
            return files.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            final ImageView preview;
            final TextView kind, name, meta;
            final ImageButton share, delete;

            ViewHolder(View itemView) {
                super(itemView);
                preview = itemView.findViewById(R.id.galleryPreview);
                kind = itemView.findViewById(R.id.galleryKind);
                name = itemView.findViewById(R.id.galleryFileName);
                meta = itemView.findViewById(R.id.galleryFileMeta);
                share = itemView.findViewById(R.id.btnGalleryShare);
                delete = itemView.findViewById(R.id.btnGalleryDelete);
            }
        }
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        urlInput.clearFocus();
    }

    // ─── Lifecycle ────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause()   { super.onPause();   webView.onPause();   }
    @Override protected void onResume()  { super.onResume();  webView.onResume();  }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        webView.destroy();
    }
}
